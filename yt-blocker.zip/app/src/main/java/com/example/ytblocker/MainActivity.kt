package com.example.ytblocker

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    // ───────── الألوان ─────────
    private val cBg = Color.parseColor("#0A0A0C")
    private val cCard = Color.parseColor("#141418")
    private val cCardAlt = Color.parseColor("#1C1C22")
    private val cStroke = Color.parseColor("#2A2A32")
    private val cText = Color.parseColor("#F4F4F6")
    private val cMuted = Color.parseColor("#9A9AA6")
    private val cMint = Color.parseColor("#34D399")
    private val cBlue = Color.parseColor("#60A5FA")
    private val cAmber = Color.parseColor("#FBBF24")
    private val cRose = Color.parseColor("#FB7185")

    private data class Entry(val ts: String, val phone: String, val type: String, val kind: String, val channel: String, val label: String)

    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var prefs: SharedPreferences
    private var filter = "الكل"
    private var shown = 100
    private var techOpen = false
    private var unlocked = false
    private val expanded = mutableSetOf<String>()

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "activitylog") runOnUiThread { rebuild(keepScroll = true) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("diag", Context.MODE_PRIVATE)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        scroll = ScrollView(this).apply {
            setBackgroundColor(cBg)
            isVerticalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(40))
        }
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        if (!unlocked) {
            if (!Control.hasPin(this)) showSetPin(first = true) else showPinGate()
        } else {
            setContentView(scroll)
            rebuild(keepScroll = false)
            if (usageDays == null) loadUsage(rebuildAfter = true)
            if (searchEntries == null) loadSearchLog(rebuildAfter = true)
            if (tozyActivity == null) loadTozyActivity(rebuildAfter = true)
        }
    }

    // ───────── سجل نشاط جوال الولد (Tozy) ─────────
    private var tozyActivity: List<Sync.ActivityEntry>? = null
    private var tozyActivityLoading = false

    private fun loadTozyActivity(rebuildAfter: Boolean) {
        if (tozyActivityLoading) return
        tozyActivityLoading = true
        Sync.pullActivity(this) { entries, _ ->
            runOnUiThread {
                tozyActivityLoading = false
                tozyActivity = entries
                if (rebuildAfter) rebuild(keepScroll = true)
            }
        }
    }

    // رابط أو كلمة بحث؟ تخمين بسيط: فيه نقطة وبدون مسافات = رابط
    private fun looksLikeLink(q: String): Boolean {
        val t = q.trim()
        return (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("www.")) ||
            (!t.contains(" ") && t.contains(".") && t.length > 4)
    }

    // يدمج: السجل المحلي (هذا الجهاز) + نشاط جوال الولد (Tozy عبر المزامنة) + البحث/الروابط (Tozy)
    private fun combinedEntries(): List<Entry> {
        val local = readEntries()
        val remote = (tozyActivity ?: emptyList()).map { a ->
            Entry(a.ts, "Tozy", a.type, a.kind, a.channel, a.label)
        }
        val searchAndLinks = (searchEntries ?: emptyList()).map { s ->
            val type = if (looksLikeLink(s.query)) "رابط" else "بحث"
            Entry(s.ts, s.app, type, "", s.app, s.query)
        }
        return (local + remote + searchAndLinks).sortedByDescending { it.ts }
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onPause()
    }

    // ───────── شاشة الرمز السري ─────────
    private fun gateCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(22), dp(26), dp(22), dp(26))
        background = bg(cCard, 22f, cStroke)
    }

    private fun pinField(hint: String) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(cMuted); setTextColor(cText)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        gravity = Gravity.CENTER
        textSize = 20f
        background = bg(cBg, 14f, cStroke)
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun gateButton(t: String, color: Int, onClick: () -> Unit) = tv(t, 15f, Color.BLACK, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(13), dp(16), dp(13))
        background = bg(color, 100f)
        setOnClickListener { onClick() }
    }

    private fun showSetPin(first: Boolean) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val c = gateCard()
        c.addView(tv(if (first) "أهلاً، حددي رمز دخول لتطبيق 5al" else "رمز جديد", 18f, cText, true))
        c.addView(tv("رقم من 4 خانات يطلبه التطبيق كل ما تفتحينه", 13f, cMuted).apply { setPadding(0, dp(8), 0, dp(18)) })
        val p1 = pinField("الرمز (4 أرقام)"); c.addView(p1, lp(MATCH, WRAP))
        val p2 = pinField("تأكيد الرمز"); c.addView(p2, lp(MATCH, WRAP, 14))
        c.addView(gateButton("حفظ", cMint) {
            val a = p1.text.toString(); val b = p2.text.toString()
            when {
                a.length != 4 -> Toast.makeText(this, "الرمز لازم يكون 4 أرقام", Toast.LENGTH_SHORT).show()
                a != b -> Toast.makeText(this, "الرمزين غير متطابقين", Toast.LENGTH_SHORT).show()
                else -> {
                    Control.setPin(this, a)
                    Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
                    unlocked = true; setContentView(scroll); rebuild(keepScroll = false)
                }
            }
        }, lp(MATCH, WRAP, 18))
        root.addView(c, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun showPinGate() {
        val remaining = Control.lockRemainingSeconds(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBg)
            setPadding(dp(24), dp(24), dp(24), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val c = gateCard()
        c.addView(tv("5al", 18f, cText, true))
        if (remaining > 0) {
            c.addView(tv("محاولات كثيرة، حاولي بعد $remaining ثانية", 13f, cRose).apply { setPadding(0, dp(10), 0, dp(10)) })
            root.addView(c, lp(MATCH, WRAP))
            setContentView(root)
            c.postDelayed({ if (!unlocked) showPinGate() }, 1000)
            return
        }
        c.addView(tv("أدخلي الرمز السري", 13f, cMuted).apply { setPadding(0, dp(8), 0, dp(18)) })
        val p = pinField("الرمز"); c.addView(p, lp(MATCH, WRAP))
        c.addView(gateButton("دخول", cMint) {
            if (Control.checkPin(this, p.text.toString())) {
                Control.resetFails(this)
                unlocked = true; setContentView(scroll); rebuild(keepScroll = false)
            } else {
                val n = Control.registerFail(this)
                Toast.makeText(this, "رمز غير صحيح", Toast.LENGTH_SHORT).show()
                if (n >= 3) showPinGate() else p.text.clear()
            }
        }, lp(MATCH, WRAP, 18))
        root.addView(c, lp(MATCH, WRAP))
        setContentView(root)
    }

    // ───────── أدوات مساعدة ─────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun bg(fill: Int, radius: Float, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dpf(radius)
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun pill(text: String, color: Int, filled: Boolean = false, size: Float = 12f): TextView =
        tv(text, size, if (filled) Color.BLACK else color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = bg(if (filled) color else alpha(color, 40), 100f)
        }

    private fun lp(w: Int, h: Int, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top) }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun typeColor(t: String) = when (t) {
        "مشاهدة" -> cBlue
        "إخفاء" -> cAmber
        "حجب" -> cRose
        "كان مشترك" -> cAmber
        "ألغيت الاشتراك" -> cMint
        "تعذر الإلغاء" -> cRose
        "انتهى الفحص", "بدأ الفحص" -> cBlue
        else -> cMuted
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val full = "$packageName/${BlockerService::class.java.name}"
        val short = "$packageName/.BlockerService"
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun readEntries(): List<Entry> {
        val raw = prefs.getString("activitylog", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.map { line ->
            val p6 = line.split(" | ", limit = 6)
            if (p6.size == 6) {
                val type = when (p6[2]) { "تغطية" -> "إخفاء"; "رجوع" -> "حجب"; else -> p6[2] }
                Entry(p6[0], p6[1], type, p6[3], p6[4], p6[5])
            } else {
                // سطور قديمة بصيغة سابقة (4 حقول بدون نوع المحتوى والقناة)
                val p4 = line.split(" | ", limit = 4)
                if (p4.size == 4) {
                    val type = when (p4[2]) { "تغطية" -> "إخفاء"; "رجوع" -> "حجب"; else -> p4[2] }
                    Entry(p4[0], p4[1], type, "", "", p4[3])
                } else Entry("", "", "", "", "", line)
            }
        }
    }

    // ───────── بناء الشاشة ─────────
    private fun rebuild(keepScroll: Boolean) {
        val y = scroll.scrollY
        content.removeAllViews()
        val entries = combinedEntries()
        content.addView(header())
        val controlOnly = Control.isControlOnly(this)
        if (!controlOnly) {
            content.addView(statusCard(), lp(MATCH, WRAP, 18))
            content.addView(controlCard(), lp(MATCH, WRAP, 14))
        }
        content.addView(syncCard(), lp(MATCH, WRAP, if (controlOnly) 18 else 14))
        content.addView(blockedListCard(), lp(MATCH, WRAP, 14))
        content.addView(appsCard(), lp(MATCH, WRAP, 14))
        content.addView(usageCard(), lp(MATCH, WRAP, 14))
        content.addView(searchLogCard(), lp(MATCH, WRAP, 14))
        if (!controlOnly) {
            content.addView(statsRow(entries), lp(MATCH, WRAP, 18))
            content.addView(logTitle(entries.size), lp(MATCH, WRAP, 26))
            content.addView(filters(), lp(MATCH, WRAP, 12))
        addLog(entries)
        }
        if (!controlOnly) content.addView(techCard(), lp(MATCH, WRAP, 28))
        if (keepScroll) scroll.post { scroll.scrollTo(0, y) }
    }

    private fun header(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logoBox = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setShape(GradientDrawable.OVAL)
                setColor(Color.BLACK)
                setStroke(dp(1), cStroke)
            }
        }
        logoBox.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(60), dp(60)))
        row.addView(logoBox, LinearLayout.LayoutParams(dp(60), dp(60)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv("5al", 26f, cText, true))
        col.addView(tv("يخفي القنوات المحظورة من يوتيوب ويسجّل كل ما تشاهده", 13f, cMuted).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        return row
    }

    private fun statusCard(): View {
        val on = serviceEnabled()
        val accent = if (on) cMint else cRose
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(alpha(accent, 46), cCard)
            ).apply {
                cornerRadius = dpf(22f)
                setStroke(dp(1), alpha(accent, 110))
            }
        }
        card.addView(pill(if (on) "●  الحماية مفعّلة" else "●  الحماية متوقفة", accent), LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(
            tv(
                if (on) "5al يراقب يوتيوب الآن، ويخفي القنوات المحظورة ويسجّل ما تفتحه من فيديوهات."
                else "لتشغيل الحماية: افتح إعدادات إمكانية الوصول، اختر «5al» ثم شغّله.",
                14f, cText
            ).apply { setLineSpacing(dpf(3f), 1f) },
            lp(MATCH, WRAP, 12)
        )
        card.addView(
            tv(if (on) "إعدادات الخدمة" else "تشغيل الحماية", 15f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(13), dp(16), dp(13))
                background = bg(accent, 100f)
                setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            },
            lp(MATCH, WRAP, 16)
        )
        return card
    }

    // ───────── التحكم: تشغيل/إيقاف الحجب + تغيير الرمز ─────────
    private fun controlCard(): View {
        val on = Control.isBlockingEnabled(this)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = bg(cCard, 20f, cStroke)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv("تفعيل الحجب", 14.5f, cText, true))
        col.addView(tv("إيقافه يوقف إخفاء القنوات مؤقتاً بدون حذف القائمة", 12f, cMuted).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(Switch(this).apply {
            isChecked = on
            thumbTintList = null
            setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { _, v -> Control.setBlockingEnabled(this@MainActivity, v) })
        })
        card.addView(row)
        card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 14))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col2.addView(tv("إلغاء الاشتراك تلقائياً", 14.5f, cText, true))
        col2.addView(tv("لما تنفتح قناة محظورة: يتحقق هل أنت مشترك، يسجّلها بالسجل، ويلغي الاشتراك", 12f, cMuted).apply { setPadding(0, dp(3), 0, 0) })
        row2.addView(col2, LinearLayout.LayoutParams(0, WRAP, 1f))
        row2.addView(Switch(this).apply {
            isChecked = Control.isUnsubEnabled(this@MainActivity)
            thumbTintList = null
            setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { _, v ->
                Control.setUnsubEnabled(this@MainActivity, v)
                if (v) Control.clearUnsubDone(this@MainActivity) // نعيد الفحص من الصفر
            })
        })
        card.addView(row2, lp(MATCH, WRAP, 14))
        card.addView(
            tv("فحص كل الاشتراكات وإلغاء المحظور", 13.5f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(11), dp(14), dp(11))
                background = bg(cAmber, 100f)
                setOnClickListener {
                    if (!serviceEnabled()) {
                        Toast.makeText(this@MainActivity, "فعّل خدمة الوصول أول", Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    Control.setScanActive(this@MainActivity, true)
                    val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/feed/channels"))
                    i.setPackage("com.google.android.youtube")
                    try { startActivity(i) } catch (e: Exception) {
                        Control.setScanActive(this@MainActivity, false)
                        Toast.makeText(this@MainActivity, "ما قدرت أفتح يوتيوب", Toast.LENGTH_LONG).show()
                    }
                }
            },
            lp(MATCH, WRAP, 14)
        )
        card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 14))
        card.addView(
            tv("تغيير الرمز السري", 13.5f, cBlue, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(11), dp(14), dp(11))
                background = bg(alpha(cBlue, 30), 100f)
                setOnClickListener { showSetPin(first = false) }
            },
            lp(MATCH, WRAP, 14)
        )
        return card
    }

    // ───────── مزامنة مع تطبيق Tozy ─────────
    private fun syncField(hint: String, value: String, secret: Boolean = false) = EditText(this).apply {
        setText(value)
        this.hint = hint
        setTextColor(cText)
        setHintTextColor(cMuted)
        textSize = 13f
        setSingleLine()
        background = bg(cCardAlt, 12f, cStroke)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun syncCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = bg(cCard, 20f, cStroke)
        }
        val coRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val coCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        coCol.addView(tv("وضع التحكم فقط", 14f, cText, true))
        coCol.addView(tv("مشغّل = هذا الجهاز يتحكم بالقوائم بدون ما يحجب عليه؛ مطفي = يحجب هنا أيضاً", 12f, cMuted).apply { setPadding(0, dp(3), 0, 0) })
        coRow.addView(coCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        coRow.addView(Switch(this).apply {
            isChecked = Control.isControlOnly(this@MainActivity)
            thumbTintList = null
            setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { _, v ->
                Control.setControlOnly(this@MainActivity, v)
                rebuild(keepScroll = true)
            })
        })
        card.addView(coRow, lp(MATCH, WRAP, 4))
        card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 12))
        card.addView(tv("المزامنة مع Tozy", 14.5f, cText, true))
        card.addView(tv("أي تغيير تسويه بالقوائم أو التفعيل يوصل تطبيق Tozy تلقائياً", 12f, cMuted).apply { setPadding(0, dp(3), 0, dp(10)) })
        val iconRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val iconCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        iconCol.addView(tv("إظهار أيقونة Tozy", 14f, cText, true))
        iconCol.addView(tv("مطفي = الأيقونة مخفية من الشاشة، مشغّل = تظهر", 12f, cMuted).apply { setPadding(0, dp(3), 0, 0) })
        iconRow.addView(iconCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        iconRow.addView(Switch(this).apply {
            isChecked = Control.isTozyIconVisible(this@MainActivity)
            thumbTintList = null
            setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener { _, v -> Control.setTozyIconVisible(this@MainActivity, v) })
        })
        card.addView(iconRow, lp(MATCH, WRAP, 4))
        card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 12))
        val fUrl = syncField("رابط الوسيط", Sync.url(this))
        val fPair = syncField("كود الربط", Sync.pair(this))
        val fKey = syncField("المفتاح السري", Sync.key(this), secret = true)
        card.addView(fUrl, lp(MATCH, WRAP, 12))
        card.addView(fPair, lp(MATCH, WRAP, 8))
        card.addView(fKey, lp(MATCH, WRAP, 8))
        card.addView(tv(Sync.lastStatus(this), 11.5f, cMuted), lp(MATCH, WRAP, 8))
        card.addView(
            tv("حفظ ومزامنة الحين", 13.5f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(11), dp(14), dp(11))
                background = bg(cMint, 100f)
                setOnClickListener {
                    Sync.save(this@MainActivity, fUrl.text.toString(), fPair.text.toString(), fKey.text.toString())
                    Sync.push(this@MainActivity) { ok, msg ->
                        runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }
                    }
                }
            },
            lp(MATCH, WRAP, 12)
        )
        return card
    }

    // ───────── القنوات والأسماء المحظورة ─────────
    private fun blockedListCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = bg(cCard, 20f, cStroke)
        }
        card.addView(tv("القنوات والأسماء المحظورة", 15f, cText, true))

        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(listBox, lp(MATCH, WRAP, 10))

        val items = Control.getHandles(this).map { "@" to it } +
            Control.getNames(this).map { "اسم" to it } +
            Control.getExact(this).map { "كلمة" to it }
        if (items.isEmpty()) {
            listBox.addView(tv("القائمة فاضية", 12.5f, cMuted))
        }
        items.forEach { (tagType, value) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(pill(tagType, cMuted, size = 10.5f))
            row.addView(tv(value, 13f, cText), LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(8) })
            row.addView(tv("حذف", 12.5f, cRose, true).apply {
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    when (tagType) {
                        "@" -> Control.setHandles(this@MainActivity, Control.getHandles(this@MainActivity) - value)
                        "اسم" -> Control.setNames(this@MainActivity, Control.getNames(this@MainActivity) - value)
                        else -> Control.setExact(this@MainActivity, Control.getExact(this@MainActivity) - value)
                    }
                    rebuild(keepScroll = true)
                }
            })
            listBox.addView(row, lp(MATCH, WRAP, 8))
        }

        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addField = EditText(this).apply {
            hint = "أضيفي معرّف @ أو اسم قناة"
            setHintTextColor(cMuted); setTextColor(cText)
            background = bg(cBg, 14f, cStroke)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            textSize = 14f
        }
        addRow.addView(addField, LinearLayout.LayoutParams(0, WRAP, 1f))
        addRow.addView(
            tv("إضافة", 13.5f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = bg(cMint, 100f)
                setOnClickListener {
                    val v = addField.text.toString().trim()
                    if (v.isNotEmpty()) {
                        if (v.startsWith("@")) Control.setHandles(this@MainActivity, Control.getHandles(this@MainActivity) + v)
                        else Control.setNames(this@MainActivity, Control.getNames(this@MainActivity) + v)
                        rebuild(keepScroll = true)
                    }
                }
            },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(10) }
        )
        card.addView(addRow, lp(MATCH, WRAP, 14))
        return card
    }

    // ───────── تطبيقات تُحجب بالكامل، وتطبيقات يُفحص بداخلها نص القوائم ─────────
    private fun resolveAppLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { "" }

    private fun appIdRow(pkg: String, onRemove: () -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = resolveAppLabel(pkg)
        if (label.isNotEmpty()) col.addView(tv(label, 13.5f, cText, true))
        col.addView(tv(pkg, 11.5f, cMuted))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(tv("حذف", 12.5f, cRose, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { onRemove() }
        })
        return row
    }

    private fun appIdAddRow(hint: String, onAdd: (String) -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val field = EditText(this).apply {
            this.hint = hint
            setHintTextColor(cMuted); setTextColor(cText)
            background = bg(cBg, 14f, cStroke)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            textSize = 13f
            textDirection = View.TEXT_DIRECTION_LTR
        }
        row.addView(field, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(
            tv("إضافة", 13.5f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = bg(cMint, 100f)
                setOnClickListener {
                    val v = field.text.toString().trim()
                    if (v.isNotEmpty()) { onAdd(v); field.text.clear() }
                }
            },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(10) }
        )
        return row
    }

    private fun appsCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = bg(cCard, 20f, cStroke)
        }
        card.addView(tv("تطبيقات تُحجب بالكامل", 15f, cText, true))
        card.addView(tv("أول ما تنفتح، ترجع للشاشة الرئيسية مباشرة (معرّف الحزمة، مثل com.kick.mobile)", 12f, cMuted).apply { setPadding(0, dp(3), 0, dp(10)) })
        val fullBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(fullBox)
        val full = Control.getFullBlockApps(this)
        if (full.isEmpty()) fullBox.addView(tv("القائمة فاضية", 12.5f, cMuted))
        full.forEach { pkg ->
            fullBox.addView(appIdRow(pkg) {
                Control.setFullBlockApps(this@MainActivity, Control.getFullBlockApps(this@MainActivity) - pkg)
                rebuild(keepScroll = true)
            }, lp(MATCH, WRAP, 8))
        }
        card.addView(appIdAddRow("معرّف حزمة (com.example.app)") { v ->
            Control.setFullBlockApps(this@MainActivity, Control.getFullBlockApps(this@MainActivity) + v)
            rebuild(keepScroll = true)
        }, lp(MATCH, WRAP, 12))

        card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 16))
        card.addView(tv("تطبيقات يُفحص محتواها", 15f, cText, true).apply { setPadding(0, dp(2), 0, 0) })
        card.addView(tv("يبحث داخلها عن نفس القنوات/الأسماء المحظورة أعلاه ويخفيها (زي يوتيوب)", 12f, cMuted).apply { setPadding(0, dp(3), 0, dp(10)) })
        val scanBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(scanBox)
        val scan = Control.getScanApps(this)
        if (scan.isEmpty()) scanBox.addView(tv("القائمة فاضية", 12.5f, cMuted))
        scan.forEach { pkg ->
            scanBox.addView(appIdRow(pkg) {
                Control.setScanApps(this@MainActivity, Control.getScanApps(this@MainActivity) - pkg)
                rebuild(keepScroll = true)
            }, lp(MATCH, WRAP, 8))
        }
        card.addView(appIdAddRow("معرّف حزمة (com.example.app)") { v ->
            Control.setScanApps(this@MainActivity, Control.getScanApps(this@MainActivity) + v)
            rebuild(keepScroll = true)
        }, lp(MATCH, WRAP, 12))

        card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 16))
        card.addView(tv("تطبيقات يُسجَّل بحثها", 15f, cText, true).apply { setPadding(0, dp(2), 0, 0) })
        card.addView(tv("يسجّل كلمة البحث فقط من صندوق البحث داخل هذي التطبيقات (مو أي حقل نص ثاني بالتطبيق)", 12f, cMuted).apply { setPadding(0, dp(3), 0, dp(10)) })
        val searchBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(searchBox)
        val search = Control.getSearchApps(this)
        if (search.isEmpty()) searchBox.addView(tv("القائمة فاضية", 12.5f, cMuted))
        search.forEach { pkg ->
            searchBox.addView(appIdRow(pkg) {
                Control.setSearchApps(this@MainActivity, Control.getSearchApps(this@MainActivity) - pkg)
                rebuild(keepScroll = true)
            }, lp(MATCH, WRAP, 8))
        }
        card.addView(appIdAddRow("معرّف حزمة (com.example.app)") { v ->
            Control.setSearchApps(this@MainActivity, Control.getSearchApps(this@MainActivity) + v)
            rebuild(keepScroll = true)
        }, lp(MATCH, WRAP, 12))
        return card
    }

    // ───────── تقرير استخدام التطبيقات (يرفعه Tozy تلقائياً) ─────────
    private var usageDays: List<Sync.UsageDay>? = null
    private var usageStatus = "اضغطي تحديث لجلب آخر تقرير"
    private var usageLoading = false

    private var searchEntries: List<Sync.SearchEntry>? = null
    private var searchStatus = "اضغطي تحديث لجلب آخر سجل بحث"
    private var searchLoading = false

    private fun loadSearchLog(rebuildAfter: Boolean) {
        if (searchLoading) return
        searchLoading = true
        Sync.pullSearchLog(this) { entries, msg ->
            runOnUiThread {
                searchLoading = false
                searchEntries = entries
                searchStatus = msg
                if (rebuildAfter) rebuild(keepScroll = true)
            }
        }
    }

    // ───────── سجل البحث (آخر كلمات البحث اللي رفعها Tozy من صناديق البحث المحدَّدة) ─────────
    private fun searchLogCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = bg(cCard, 20f, cStroke)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("سجل البحث", 15f, cText, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(pill(if (searchLoading) "..." else "تحديث", cBlue).apply {
            setOnClickListener { loadSearchLog(rebuildAfter = true) }
        })
        card.addView(head)
        card.addView(
            tv("آخر كلمات البحث والروابط داخل التطبيقات المحددة أعلاه فقط (يوتيوب، كروم، جوجل، أو أي تطبيق أضفتيه)", 12f, cMuted)
                .apply { setPadding(0, dp(4), 0, dp(10)) }
        )

        val entries = searchEntries
        if (entries == null) {
            card.addView(tv(searchStatus, 12.5f, cMuted))
        } else if (entries.isEmpty()) {
            card.addView(tv("ما في عمليات بحث مسجّلة بعد", 12.5f, cMuted))
        } else {
            entries.take(60).forEach { s ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                col.addView(tv(s.query, 13.5f, cText).apply {
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                val meta = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                meta.addView(pill(s.label, cMuted, size = 10.5f))
                val time = if (s.ts.length >= 16) s.ts.substring(11, 16) else s.ts
                meta.addView(tv(time, 11f, cMuted), LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
                col.addView(meta, lp(MATCH, WRAP, 4))
                row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
                card.addView(row, lp(MATCH, WRAP, 12))
                card.addView(View(this).apply { setBackgroundColor(cStroke) }, lp(MATCH, 1, 10))
            }
        }
        return card
    }

    private fun loadUsage(rebuildAfter: Boolean) {
        if (usageLoading) return
        usageLoading = true
        Sync.pullUsage(this) { days, msg ->
            runOnUiThread {
                usageLoading = false
                usageDays = days
                usageStatus = msg
                if (rebuildAfter) rebuild(keepScroll = true)
            }
        }
    }

    private fun usageCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = bg(cCard, 20f, cStroke)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("تقرير استخدام الجوال", 15f, cText, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(pill(if (usageLoading) "..." else "تحديث", cBlue).apply {
            setOnClickListener { loadUsage(rebuildAfter = true) }
        })
        card.addView(head)
        card.addView(tv("كم دقيقة قضى بكل تطبيق، يوم بيوم (يحتاج Tozy يكون مفعّل وصلاحية الاستخدام موافق عليها)", 12f, cMuted).apply { setPadding(0, dp(4), 0, dp(10)) })

        val days = usageDays
        if (days == null) {
            card.addView(tv(usageStatus, 12.5f, cMuted))
        } else if (days.isEmpty()) {
            card.addView(tv("ما وصل تقرير استخدام بعد", 12.5f, cMuted))
        } else {
            days.take(7).forEachIndexed { i, d ->
                card.addView(tv(d.date, 12.5f, cMuted, true), lp(MATCH, WRAP, if (i == 0) 2 else 14))
                if (d.apps.isEmpty()) {
                    card.addView(tv("لا يوجد استخدام مسجّل", 12f, cMuted), lp(MATCH, WRAP, 4))
                } else {
                    d.apps.take(8).forEach { (_, label, minutes) ->
                        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                        row.addView(tv(label, 13f, cText), LinearLayout.LayoutParams(0, WRAP, 1f))
                        row.addView(tv("$minutes د", 12.5f, cBlue, true))
                        card.addView(row, lp(MATCH, WRAP, 6))
                    }
                }
            }
        }
        return card
    }

    private fun todayPrefix(daysAgo: Int = 0): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }

    private fun statsRow(entries: List<Entry>): View {
        val today = todayPrefix()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val items = listOf("مشاهدة" to "مشاهدات اليوم", "إخفاء" to "بطاقات مخفية", "حجب" to "فيديوهات محجوبة")
        items.forEachIndexed { i, (type, title) ->
            val n = entries.count { it.type == type && it.ts.startsWith(today) }
            val c = typeColor(type)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(14), dp(8), dp(14))
                background = bg(alpha(c, 28), 18f, alpha(c, 70))
            }
            box.addView(tv(n.toString(), 24f, c, true).apply { gravity = Gravity.CENTER })
            box.addView(tv(title, 11f, cMuted).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
        return row
    }

    private fun logTitle(total: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(tv("سجل النشاط", 18f, cText, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(pill("$total", cMuted))
        if (total > 0) {
            row.addView(pill("مسح", cRose).apply {
                setOnClickListener { confirmClear() }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        }
        return row
    }

    // نوع المحتوى الفعلي للعنصر (القديم بدون نوع محفوظ يُحسب فيديو)
    private fun effectiveKind(e: Entry) = if (e.kind == "شورت") "شورت" else "فيديو"

    private fun filters(): View {
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("الكل", "فيديوهات", "شورتس", "المحجوبة", "البحث", "الروابط").forEachIndexed { i, name ->
            val selected = filter == name
            val c = when (name) {
                "الكل" -> cText
                "شورتس" -> cRose
                "المحجوبة" -> cAmber
                "البحث" -> Color.parseColor("#C084FC")
                "الروابط" -> cMint
                else -> cBlue
            }
            val chip = tv(name, 13f, if (selected) Color.BLACK else cMuted, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(8), dp(18), dp(8))
                background = if (selected) bg(c, 100f) else bg(cCardAlt, 100f, cStroke)
                setOnClickListener { filter = name; shown = 100; rebuild(keepScroll = true) }
            }
            row.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { if (i > 0) marginStart = dp(8) })
        }
        hs.addView(row)
        return hs
    }

    private fun addLog(all: List<Entry>) {
        val list = when (filter) {
            "الكل" -> all
            "المحجوبة" -> all.filter { it.type == "حجب" }
            "البحث" -> all.filter { it.type == "بحث" }
            "الروابط" -> all.filter { it.type == "رابط" }
            "فيديوهات", "شورتس" -> all.filter { it.type != "بحث" && it.type != "رابط" && effectiveKind(it) == (if (filter == "شورتس") "شورت" else "فيديو") }
            else -> all
        }
        if (list.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(34), dp(20), dp(34))
                background = bg(cCard, 20f, cStroke)
            }
            empty.addView(tv("لا يوجد نشاط بعد", 16f, cText, true).apply { gravity = Gravity.CENTER })
            empty.addView(
                tv("افتح يوتيوب وشاهد أي فيديو، وسيظهر هنا فورًا.", 13f, cMuted).apply {
                    gravity = Gravity.CENTER
                    setPadding(0, dp(6), 0, 0)
                }
            )
            content.addView(empty, lp(MATCH, WRAP, 14))
            return
        }
        val today = todayPrefix()
        val yesterday = todayPrefix(1)
        var lastDay = ""
        list.take(shown).forEach { e ->
            val day = if (e.ts.length >= 10) e.ts.substring(0, 10) else ""
            if (day != lastDay) {
                lastDay = day
                val name = when (day) { today -> "اليوم"; yesterday -> "أمس"; "" -> "—"; else -> day }
                content.addView(tv(name, 12f, cMuted, true), lp(MATCH, WRAP, 18))
            }
            content.addView(entryCard(e), lp(MATCH, WRAP, 8))
        }
        if (list.size > shown) {
            content.addView(
                tv("عرض المزيد (${list.size - shown})", 14f, cText, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    background = bg(cCardAlt, 100f, cStroke)
                    setOnClickListener { shown += 100; rebuild(keepScroll = true) }
                },
                lp(MATCH, WRAP, 16)
            )
        }
    }

    // عنوان بسيط بدل المصطلحات التقنية
    private fun simpleStatus(e: Entry): Pair<String, Int> = when (e.type) {
        "مشاهدة" -> "تمت مشاهدته" to cBlue
        "إخفاء" -> "مخفي تلقائياً" to cAmber
        "حجب" -> "تم إغلاقه (محظور)" to cRose
        "كان مشترك" -> "كنت مشترك بالقناة" to cAmber
        "ألغيت الاشتراك" -> "تم إلغاء الاشتراك" to cMint
        "غير مشترك" -> "ما كنت مشترك" to cMuted
        "تعذر الإلغاء" -> "تعذّر إلغاء الاشتراك" to cRose
        "تعذر التحقق" -> "ما قدرنا نتحقق من الاشتراك" to cMuted
        "بدأ الفحص" -> "بدأ فحص الاشتراكات" to cBlue
        "انتهى الفحص" -> "انتهى فحص الاشتراكات" to cBlue
        "بحث" -> "كلمة بحث" to Color.parseColor("#C084FC")
        "رابط" -> "رابط مفتوح" to cMint
        else -> (e.type.ifBlank { "—" }) to cMuted
    }

    private fun entryKey(e: Entry) = "${e.ts}|${e.label}"

    private fun isTargetBlocked(target: String): Boolean {
        val t = target.trim()
        if (t.isEmpty()) return false
        return Control.getHandles(this).any { it.equals(t, true) } ||
            Control.getNames(this).any { it.equals(t, true) } ||
            Control.getExact(this).any { it.equals(t, true) }
    }

    private fun blockTarget(target: String) {
        val t = target.trim()
        if (t.isEmpty()) return
        if (t.startsWith("@")) Control.setHandles(this, Control.getHandles(this) + t)
        else Control.setNames(this, Control.getNames(this) + t)
    }

    private fun unblockTarget(target: String) {
        val t = target.trim()
        Control.setHandles(this, Control.getHandles(this).filterNot { it.equals(t, true) })
        Control.setNames(this, Control.getNames(this).filterNot { it.equals(t, true) })
        Control.setExact(this, Control.getExact(this).filterNot { it.equals(t, true) })
    }

    private fun entryCard(e: Entry): View {
        val isSearchOrLink = e.type == "بحث" || e.type == "رابط"
        val kind = effectiveKind(e)
        val kindColor = if (isSearchOrLink) (if (e.type == "رابط") cMint else Color.parseColor("#C084FC")) else if (kind == "شورت") cRose else cBlue
        val (statusText, statusColor) = simpleStatus(e)
        val key = entryKey(e)
        // الهدف القابل للحجب/فك الحجب: اسم القناة إن وجد، وإلا نص العنصر نفسه (غير متاح لعناصر البحث/الروابط)
        val target = if (isSearchOrLink) "" else e.channel.ifBlank { e.label }.trim()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = bg(cCard, 18f, cStroke)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

        // أيقونة بدل الصورة المصغّرة (التطبيق ما يقدر ياخذ صورة الفيديو الحقيقية)
        val iconBox = FrameLayout(this).apply {
            background = bg(alpha(kindColor, 40), 14f)
        }
        val icon = when {
            e.type == "بحث" -> "🔍"
            e.type == "رابط" -> "🔗"
            kind == "شورت" -> "⚡"
            else -> "▶"
        }
        iconBox.addView(tv(icon, 18f, kindColor, true).apply { gravity = Gravity.CENTER })
        row.addView(iconBox, LinearLayout.LayoutParams(dp(44), dp(44)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(
            tv(e.label.ifBlank { "—" }, 14.5f, cText).apply {
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setLineSpacing(dpf(2f), 1f)
            }
        )
        val metaRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        metaRow.addView(pill(statusText, statusColor, size = 10.5f))
        val time = if (e.ts.length >= 16) e.ts.substring(11, 16) else ""
        metaRow.addView(tv(time, 11.5f, cMuted), LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        col.addView(metaRow, lp(MATCH, WRAP, 4))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(10) })

        // السهم: يفتح/يقفل قائمة تحكم سريعة
        val isOpen = expanded.contains(key)
        row.addView(
            tv(if (isOpen) "▲" else "▼", 13f, cMuted, true).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setOnClickListener {
                    if (isOpen) expanded.remove(key) else expanded.add(key)
                    rebuild(keepScroll = true)
                }
            }
        )
        card.addView(row)

        if (isOpen) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(4))
            }
            if (target.isNotBlank()) {
                val blocked = isTargetBlocked(target)
                box.addView(
                    tv(if (blocked) "فك الحجب عن: $target" else "حجب: $target", 13f, Color.BLACK, true).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(14), dp(11), dp(14), dp(11))
                        background = bg(if (blocked) cMint else cRose, 100f)
                        setOnClickListener {
                            if (blocked) unblockTarget(target) else blockTarget(target)
                            Toast.makeText(
                                this@MainActivity,
                                if (blocked) "تم فك الحجب" else "تم الحجب، راح يختفي القادم",
                                Toast.LENGTH_SHORT
                            ).show()
                            rebuild(keepScroll = true)
                        }
                    },
                    lp(MATCH, WRAP, 2)
                )
            } else {
                val msg = if (isSearchOrLink) "ما فيه حجب لعناصر البحث والروابط" else "ما قدرنا نحدد اسم القناة لهذا العنصر"
                box.addView(tv(msg, 12f, cMuted), lp(MATCH, WRAP, 2))
            }
            box.addView(
                tv("باقي الخيارات (عدم مهم، عدم الاقتراح) تصير لحظة ظهور الفيديو بيوتيوب نفسه، وما نقدر نفعّلها من السجل بعد ما يفوت وقتها.", 11f, cMuted).apply {
                    setPadding(0, dp(10), 0, 0)
                    setLineSpacing(dpf(2f), 1f)
                },
                lp(MATCH, WRAP, 2)
            )
            card.addView(box, lp(MATCH, WRAP, 2))
        }

        if (e.phone.isNotBlank()) {
            card.addView(tv(e.phone, 11f, alpha(cMuted, 170)), lp(MATCH, WRAP, 6))
        }
        return card
    }

    private fun confirmClear() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("مسح السجل؟")
            .setMessage("سيتم حذف كل الأنشطة المسجّلة من هذا الجهاز.")
            .setPositiveButton("مسح") { _, _ ->
                prefs.edit().remove("activitylog").apply()
                rebuild(keepScroll = false)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────── تفاصيل للمطوّر (مطويّة افتراضيًا) ─────────
    private fun techText(): String {
        fun g(k: String, d: String = "-") = prefs.getString(k, d) ?: d
        return "الحالة:\n" + g("status", "الخدمة لم تستقبل شيئًا بعد (هل هي مفعّلة؟)") +
            "\n\nالفيديو المعروض:\n" + g("watching") +
            "\n\nالمطابقات:\n" + g("matches") +
            "\n\nأزرار:\n" + g("controls") +
            "\n\nالمشغّل المصغّر:\n" + g("mini") +
            "\n\nالعناصر:\n" + g("ids", "")
    }

    private fun techCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(cCard, 18f, cStroke)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { techOpen = !techOpen; rebuild(keepScroll = true) }
        }
        head.addView(tv("تفاصيل تقنية", 14f, cMuted, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(tv(if (techOpen) "▲" else "▼", 12f, cMuted))
        card.addView(head)
        if (techOpen) {
            val body = techText()
            card.addView(
                tv(body, 11f, cMuted).apply {
                    typeface = Typeface.MONOSPACE
                    textDirection = View.TEXT_DIRECTION_LTR
                    setTextIsSelectable(true)
                },
                lp(MATCH, WRAP, 12)
            )
            card.addView(
                pill("نسخ التفاصيل", cBlue).apply {
                    setOnClickListener {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("5al", body))
                        Toast.makeText(this@MainActivity, "تم النسخ", Toast.LENGTH_SHORT).show()
                    }
                },
                lp(WRAP, WRAP, 12)
            )
        }
        return card
    }
}
