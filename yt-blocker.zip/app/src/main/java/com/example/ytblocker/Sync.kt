package com.example.ytblocker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

// يرسل قوائم الحجب لوسيط Cloudflare عشان تطبيق Tozy يجلبها
object Sync {
    const val DEFAULT_URL = "https://nataij-api.myshuruhat.workers.dev"
    const val DEFAULT_PAIR = "xeb3vuyM0FOa"

    private fun p(ctx: Context) = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE)
    fun url(ctx: Context) = p(ctx).getString("url", DEFAULT_URL) ?: DEFAULT_URL
    fun pair(ctx: Context) = p(ctx).getString("pair", DEFAULT_PAIR) ?: DEFAULT_PAIR
    fun key(ctx: Context) = p(ctx).getString("key", "") ?: ""
    fun save(ctx: Context, url: String, pair: String, key: String) {
        p(ctx).edit().putString("url", url.trim().trimEnd('/')).putString("pair", pair.trim()).putString("key", key.trim()).apply()
    }
    fun configured(ctx: Context) = key(ctx).isNotBlank() && pair(ctx).isNotBlank() && url(ctx).isNotBlank()

    private val gen = AtomicLong()

    private fun arr(l: List<String>): JSONArray { val a = JSONArray(); l.forEach { a.put(it) }; return a }

    // يرسل بعد ثانية ونصف (لو تغيّر شي ثاني قبلها نرسل آخر نسخة بس). onResult يرسل فوراً.
    fun push(ctx0: Context, onResult: ((Boolean, String) -> Unit)? = null) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult?.invoke(false, "عبّي المفتاح السري أول"); return }
        val my = gen.incrementAndGet()
        Thread {
            try {
                if (onResult == null) Thread.sleep(1500)
                if (my != gen.get()) return@Thread
                val body = JSONObject()
                    .put("handles", arr(Control.getHandles(ctx)))
                    .put("names", arr(Control.getNames(ctx)))
                    .put("exact", arr(Control.getExact(ctx)))
                    .put("blocking", Control.isBlockingEnabled(ctx))
                    .put("icon", Control.isTozyIconVisible(ctx))
                    .put("fullBlockApps", arr(Control.getFullBlockApps(ctx)))
                    .put("scanApps", arr(Control.getScanApps(ctx)))
                    .put("searchApps", arr(Control.getSearchApps(ctx)))
                val c = URL(url(ctx) + "/blocklist?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-admin-key", key(ctx))
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val ok = code in 200..299
                p(ctx).edit().putString("last", if (ok) "تمت المزامنة " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) else "فشلت المزامنة ($code)").apply()
                onResult?.invoke(ok, if (ok) "تمت المزامنة" else if (code == 401) "المفتاح السري غلط" else "فشلت ($code)")
            } catch (e: Exception) {
                p(ctx).edit().putString("last", "فشلت المزامنة (ما في نت)").apply()
                onResult?.invoke(false, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }
    fun lastStatus(ctx: Context) = p(ctx).getString("last", "ما تمت مزامنة بعد") ?: ""

    // ───────── سحب سجل عمليات البحث (اللي رفعه Tozy من صناديق البحث المحدَّدة فقط) ─────────
    class SearchEntry(val ts: String, val app: String, val label: String, val query: String)

    fun pullSearchLog(ctx0: Context, onResult: (List<SearchEntry>?, String) -> Unit) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult(null, "عبّي المفتاح السري أول"); return }
        Thread {
            try {
                val c = URL(url(ctx) + "/searchlog?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) { onResult(null, "فشل الطلب (${c.responseCode})"); return@Thread }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(txt)
                val arr = o.optJSONArray("entries") ?: JSONArray()
                val list = (0 until arr.length()).map { i ->
                    val e = arr.getJSONObject(i)
                    val app = e.optString("app")
                    SearchEntry(e.optString("ts"), app, e.optString("label").ifBlank { app }, e.optString("q"))
                }
                onResult(list, if (list.isEmpty()) "ما في عمليات بحث مسجّلة بعد" else "")
            } catch (e: Exception) {
                onResult(null, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }

    // ───────── سحب تقرير استخدام التطبيقات (اللي رفعه Tozy) لعرضه بتطبيق الأم ─────────
    class UsageDay(val date: String, val apps: List<Triple<String, String, Int>>) // pkg, label, minutes

    fun pullUsage(ctx0: Context, onResult: (List<UsageDay>?, String) -> Unit) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult(null, "عبّي المفتاح السري أول"); return }
        Thread {
            try {
                val c = URL(url(ctx) + "/usage?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) { onResult(null, "فشل الطلب (${c.responseCode})"); return@Thread }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(txt)
                val days = o.keys().asSequence().map { date ->
                    val day = o.getJSONObject(date)
                    val appsArr = day.optJSONArray("apps") ?: JSONArray()
                    val apps = (0 until appsArr.length()).map { i ->
                        val a = appsArr.getJSONObject(i)
                        Triple(a.optString("pkg"), a.optString("label"), a.optInt("minutes"))
                    }.sortedByDescending { it.third }
                    UsageDay(date, apps)
                }.sortedByDescending { it.date }.toList()
                onResult(days, if (days.isEmpty()) "ما في تقرير استخدام بعد" else "")
            } catch (e: Exception) {
                onResult(null, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }
}
