package com.example.ytblocker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

// يرسل قوائم الحجب لوسيط Cloudflare عشان تطبيق Tozy يجلبها
object Sync {
    const val DEFAULT_URL = "https://nataij-api.myshuruhat.workers.dev"
    const val DEFAULT_PAIR = "xeb3vuyM0FOa"

    private fun p(ctx: Context) = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE)
    fun url(ctx: Context) = p(ctx).getString("url", DEFAULT_URL) ?: DEFAULT_URL
    fun pair(ctx: Context) = p(ctx).getString("pair", DEFAULT_PAIR) ?: DEFAULT_PAIR
    fun key(ctx: Context) = p(ctx).getString("key", "") ?: ""
    fun save(ctx: Context, url: String, pair: String, key: String) {
        p(ctx).edit().putString("url", url.trim().trimEnd('/')).putString("pair", pair.trim()).putString("key", key.trim()).apply()
    }
    fun configured(ctx: Context) = key(ctx).isNotBlank() && pair(ctx).isNotBlank() && url(ctx).isNotBlank()

    private val gens = ConcurrentHashMap<String, AtomicLong>()

    private fun arr(l: List<String>): JSONArray { val a = JSONArray(); l.forEach { a.put(it) }; return a }

    // يرسل بعد ثانية ونصف (لو تغيّر شي ثاني قبلها نرسل آخر نسخة بس). onResult يرسل فوراً.
    fun push(ctx0: Context, onResult: ((Boolean, String) -> Unit)? = null) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult?.invoke(false, "عبّي المفتاح السري أول"); return }
        val d = Control.dev // القوائم تنرسل للجهاز اللي كان مفتوح وقت التعديل
        val g = gens.getOrPut(d) { AtomicLong() }
        val my = g.incrementAndGet()
        Thread {
            try {
                if (onResult == null) Thread.sleep(1500)
                if (my != g.get()) return@Thread
                val body = JSONObject()
                    .put("handles", arr(Control.getHandles(ctx, d)))
                    .put("names", arr(Control.getNames(ctx, d)))
                    .put("exact", arr(Control.getExact(ctx, d)))
                    .put("blocking", true) // تشغيل/إيقاف الحجب صار لكل جهاز من /devices
                    .put("fullBlockApps", arr(Control.getFullBlockApps(ctx, d)))
                    .put("scanApps", arr(Control.getScanApps(ctx, d)))
                    .put("searchApps", arr(Control.getSearchApps(ctx, d)))
                    .put("warningMessage", Control.getWarningMessage(ctx, d))
                val devQ = if (d.isBlank()) "" else "&device=$d"
                val c = URL(url(ctx) + "/blocklist?pair=" + pair(ctx) + devQ).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-admin-key", key(ctx))
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val ok = code in 200..299
                p(ctx).edit().putString("last", if (ok) "تمت المزامنة " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) else "فشلت المزامنة ($code)").apply()
                onResult?.invoke(ok, if (ok) "تمت المزامنة" else if (code == 401) "المفتاح السري غلط" else "فشلت ($code)")
            } catch (e: Exception) {
                p(ctx).edit().putString("last", "فشلت المزامنة (ما في نت)").apply()
                onResult?.invoke(false, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }
    fun lastStatus(ctx: Context) = p(ctx).getString("last", "ما تمت مزامنة بعد") ?: ""

    // ───────── سحب سجل عمليات البحث (اللي رفعه Tozy من صناديق البحث المحدَّدة فقط) ─────────
    class SearchEntry(val ts: String, val app: String, val label: String, val query: String, val deviceName: String = "", val device: String = "")

    fun pullSearchLog(ctx0: Context, onResult: (List<SearchEntry>?, String) -> Unit) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult(null, "عبّي المفتاح السري أول"); return }
        Thread {
            try {
                val c = URL(url(ctx) + "/searchlog?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) { onResult(null, "فشل الطلب (${c.responseCode})"); return@Thread }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(txt)
                val arr = o.optJSONArray("entries") ?: JSONArray()
                val list = (0 until arr.length()).map { i ->
                    val e = arr.getJSONObject(i)
                    val app = e.optString("app")
                    SearchEntry(e.optString("ts"), app, e.optString("label").ifBlank { app }, e.optString("q"), e.optString("deviceName"), e.optString("device"))
                }
                onResult(list, if (list.isEmpty()) "ما في عمليات بحث مسجّلة بعد" else "")
            } catch (e: Exception) {
                onResult(null, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }

    // ───────── سحب سجل النشاط (مشاهدة/إخفاء/حجب) اللي رفعه Tozy من جوال الولد ─────────
    class ActivityEntry(val ts: String, val type: String, val kind: String, val channel: String, val label: String, val deviceName: String = "", val device: String = "")

    fun pullActivity(ctx0: Context, onResult: (List<ActivityEntry>?, String) -> Unit) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult(null, "عبّي المفتاح السري أول"); return }
        Thread {
            try {
                val c = URL(url(ctx) + "/activity?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) { onResult(null, "فشل الطلب (${c.responseCode})"); return@Thread }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(txt)
                val arr = o.optJSONArray("entries") ?: JSONArray()
                val list = (0 until arr.length()).map { i ->
                    val e = arr.getJSONObject(i)
                    ActivityEntry(e.optString("ts"), e.optString("type"), e.optString("kind"), e.optString("channel"), e.optString("label"), e.optString("deviceName"), e.optString("device"))
                }
                onResult(list, if (list.isEmpty()) "ما في نشاط من جوال الولد بعد" else "")
            } catch (e: Exception) {
                onResult(null, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }

    // ───────── سحب تقرير استخدام التطبيقات (اللي رفعه Tozy) لعرضه بتطبيق الأم ─────────
    class UsageDay(val date: String, val apps: List<Triple<String, String, Int>>) // pkg, label, minutes

    fun pullUsage(ctx0: Context, device: String = "", onResult: (List<UsageDay>?, String) -> Unit) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult(null, "عبّي المفتاح السري أول"); return }
        Thread {
            try {
                val c = URL(url(ctx) + "/usage?pair=" + pair(ctx) + (if (device.isBlank()) "" else "&device=$device")).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) { onResult(null, "فشل الطلب (${c.responseCode})"); return@Thread }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val o = JSONObject(txt)
                val days = o.keys().asSequence().map { date ->
                    val day = o.getJSONObject(date)
                    val appsArr = day.optJSONArray("apps") ?: JSONArray()
                    val apps = (0 until appsArr.length()).map { i ->
                        val a = appsArr.getJSONObject(i)
                        Triple(a.optString("pkg"), a.optString("label"), a.optInt("minutes"))
                    }.sortedByDescending { it.third }
                    UsageDay(date, apps)
                }.sortedByDescending { it.date }.toList()
                onResult(days, if (days.isEmpty()) "ما في تقرير استخدام بعد" else "")
            } catch (e: Exception) {
                onResult(null, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }

    // ───────── الأجهزة: قائمة أجهزة Tozy المسجّلة، وتشغيل/إيقاف الحجب لكل جهاز لحاله ─────────
    data class DeviceEntry(val id: String, val name: String, val blocking: Boolean, val lastSeen: Long)

    fun pullDevices(ctx0: Context, onResult: (List<DeviceEntry>?, String) -> Unit) {
        val ctx = ctx0.applicationContext
        Thread {
            try {
                val c = URL(url(ctx) + "/devices?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                if (c.responseCode !in 200..299) { onResult(null, "فشل الطلب (${c.responseCode})"); return@Thread }
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(txt).optJSONArray("devices") ?: JSONArray()
                val list = (0 until arr.length()).map { i ->
                    val d = arr.getJSONObject(i)
                    DeviceEntry(d.optString("id"), d.optString("name", "جهاز"), d.optBoolean("blocking", true), d.optLong("lastSeen", 0L))
                }.sortedByDescending { it.lastSeen }
                onResult(list, if (list.isEmpty()) "ما سجّل أي جهاز بعد" else "")
            } catch (e: Exception) { onResult(null, "ما قدرت أتصل بالوسيط") }
        }.start()
    }

    fun pushDeviceBlocking(ctx0: Context, id: String, blocking: Boolean, onResult: (Boolean, String) -> Unit) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult(false, "عبّي المفتاح السري أول"); return }
        Thread {
            try {
                val body = JSONObject().put("id", id).put("blocking", blocking)
                val c = URL(url(ctx) + "/devices?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-admin-key", key(ctx))
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                onResult(code in 200..299, if (code == 401) "المفتاح السري غلط" else if (code !in 200..299) "فشل ($code)" else "")
            } catch (e: Exception) { onResult(false, "ما قدرت أتصل بالوسيط") }
        }.start()
    }
}
