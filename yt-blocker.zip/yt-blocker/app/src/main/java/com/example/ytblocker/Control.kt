package com.example.ytblocker

import android.content.Context
import org.json.JSONArray
import java.security.MessageDigest

// إعدادات التحكم: الرمز السري، تشغيل/إيقاف الحجب، وقوائم القنوات المحظورة القابلة للتعديل
object Control {

    private const val PREFS = "control"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val defaultHandles = listOf(
        "@d7oomy999", "@POWRibrahim", "@FRS9", "@FFearFFul", "@mjrmgames909",
        "@POWR_Rayan", "@iiGOATGamingg", "@POWR_ROB", "@xBear1", "@ABS11",
        "@Abo_treek1", "@Topz", "@Abunoo7", "@POWR_Rakan", "@Siiu-Team",
        "@POWR-Esports", "@SHoNgxxBoNg", "@xbear-plus", "@sxb3654",
        "@FRLplus", "@25KLOoODE", "@POWR.Kmstka", "@MSKplusss", "@Moskooo"
    )
    private val defaultNames = listOf(
        "d7oomy_999", "Ibrahim | ابو خليل", "Faris | فارس", "FFearFFul",
        "MjrmGames", "POWR Rayan", "iiGOATGaming", "POWR ROB",
        "ابو عابد الشمري", "Turki | ابو تريك", "TOPZ توبز", "ابو نوح",
        "POWR Rakan", "POWR eSports", "SHoNgxBoNg", "خلودي 25",
        "كمستكا", "MOSKOO"
    )
    private val defaultExact = listOf("ABS", "SXB", "F R S", "FRL+", "MSK+")

    // ───────── تشغيل/إيقاف الحجب ─────────
    fun isBlockingEnabled(ctx: Context) = p(ctx).getBoolean("blocking_enabled", true)
    fun setBlockingEnabled(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("blocking_enabled", v).apply(); Sync.push(ctx) }

    // ───────── إلغاء الاشتراك التلقائي ─────────
    fun isUnsubEnabled(ctx: Context) = p(ctx).getBoolean("unsub_enabled", true)
    fun setUnsubEnabled(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("unsub_enabled", v).apply()
    // القنوات اللي انفحصت/انلغى اشتراكها (مفتاح مطبَّع) عشان ما نعيد الفحص كل مرة
    fun isUnsubDone(ctx: Context, key: String): Boolean {
        val raw = p(ctx).getString("unsub_done", "") ?: ""
        return raw.split("\n").contains(key)
    }
    fun markUnsubDone(ctx: Context, key: String) {
        val raw = p(ctx).getString("unsub_done", "") ?: ""
        val l = raw.split("\n").filter { it.isNotBlank() }
        if (key in l) return
        p(ctx).edit().putString("unsub_done", (l + key).joinToString("\n")).apply()
    }
    fun clearUnsubDone(ctx: Context) = p(ctx).edit().remove("unsub_done").apply()

    // إظهار/إخفاء أيقونة Tozy على جوال الابن (الافتراضي: مخفية)
    fun isTozyIconVisible(ctx: Context) = p(ctx).getBoolean("tozy_icon", false)
    fun setTozyIconVisible(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("tozy_icon", v).apply(); Sync.push(ctx) }

    // فحص صفحة الاشتراكات (يشتغل مرة وحدة لين يخلص أو تلغيه)
    fun isScanActive(ctx: Context) = p(ctx).getBoolean("scan_active", false)
    fun setScanActive(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("scan_active", v).apply()

    // ───────── القوائم المحظورة ─────────
    private fun getList(ctx: Context, key: String, def: List<String>): List<String> {
        val raw = p(ctx).getString(key, null)
        if (raw == null) { setList(ctx, key, def); return def }
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) { def }
    }
    private fun setList(ctx: Context, key: String, list: List<String>) {
        val arr = JSONArray(); list.forEach { arr.put(it) }
        p(ctx).edit().putString(key, arr.toString()).apply()
    }

    fun getHandles(ctx: Context) = getList(ctx, "blocked_handles", defaultHandles)
    fun setHandles(ctx: Context, l: List<String>) { setList(ctx, "blocked_handles", l); Sync.push(ctx) }
    fun getNames(ctx: Context) = getList(ctx, "blocked_names", defaultNames)
    fun setNames(ctx: Context, l: List<String>) { setList(ctx, "blocked_names", l); Sync.push(ctx) }
    fun getExact(ctx: Context) = getList(ctx, "blocked_exact", defaultExact)
    fun setExact(ctx: Context, l: List<String>) { setList(ctx, "blocked_exact", l); Sync.push(ctx) }

    // ───────── رمز الدخول (PIN) ─────────
    private fun sha256(s: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }
    fun hasPin(ctx: Context) = p(ctx).getString("pin_hash", null) != null
    fun setPin(ctx: Context, pin: String) {
        p(ctx).edit().putString("pin_hash", sha256(pin)).apply()
        resetFails(ctx)
    }
    fun checkPin(ctx: Context, pin: String) = p(ctx).getString("pin_hash", null) == sha256(pin)

    fun failCount(ctx: Context) = p(ctx).getInt("fail_count", 0)
    fun registerFail(ctx: Context): Int {
        val n = failCount(ctx) + 1
        p(ctx).edit().putInt("fail_count", n).putLong("lock_until", System.currentTimeMillis() + lockSeconds(n) * 1000L).apply()
        return n
    }
    fun resetFails(ctx: Context) = p(ctx).edit().putInt("fail_count", 0).putLong("lock_until", 0).apply()
    fun lockRemainingSeconds(ctx: Context): Long {
        val until = p(ctx).getLong("lock_until", 0)
        val rem = (until - System.currentTimeMillis()) / 1000
        return if (rem > 0) rem else 0
    }
    private fun lockSeconds(failCount: Int): Int = when {
        failCount < 3 -> 0
        failCount < 6 -> 30
        failCount < 9 -> 120
        else -> 300
    }
}
