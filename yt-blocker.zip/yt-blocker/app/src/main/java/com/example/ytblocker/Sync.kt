package com.example.ytblocker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

// يرسل قوائم الحجب لوسيط Cloudflare عشان تطبيق Tozy يجلبها
object Sync {
    const val DEFAULT_URL = "https://nataij-api.myshuruhat.workers.dev"
    const val DEFAULT_PAIR = "xeb3vuyM0FOa"

    private fun p(ctx: Context) = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE)
    fun url(ctx: Context) = p(ctx).getString("url", DEFAULT_URL) ?: DEFAULT_URL
    fun pair(ctx: Context) = p(ctx).getString("pair", DEFAULT_PAIR) ?: DEFAULT_PAIR
    fun key(ctx: Context) = p(ctx).getString("key", "") ?: ""
    fun save(ctx: Context, url: String, pair: String, key: String) {
        p(ctx).edit().putString("url", url.trim().trimEnd('/')).putString("pair", pair.trim()).putString("key", key.trim()).apply()
    }
    fun configured(ctx: Context) = key(ctx).isNotBlank() && pair(ctx).isNotBlank() && url(ctx).isNotBlank()

    private val gen = AtomicLong()

    private fun arr(l: List<String>): JSONArray { val a = JSONArray(); l.forEach { a.put(it) }; return a }

    // يرسل بعد ثانية ونصف (لو تغيّر شي ثاني قبلها نرسل آخر نسخة بس). onResult يرسل فوراً.
    fun push(ctx0: Context, onResult: ((Boolean, String) -> Unit)? = null) {
        val ctx = ctx0.applicationContext
        if (!configured(ctx)) { onResult?.invoke(false, "عبّي المفتاح السري أول"); return }
        val my = gen.incrementAndGet()
        Thread {
            try {
                if (onResult == null) Thread.sleep(1500)
                if (my != gen.get()) return@Thread
                val body = JSONObject()
                    .put("handles", arr(Control.getHandles(ctx)))
                    .put("names", arr(Control.getNames(ctx)))
                    .put("exact", arr(Control.getExact(ctx)))
                    .put("blocking", Control.isBlockingEnabled(ctx))
                    .put("icon", Control.isTozyIconVisible(ctx))
                val c = URL(url(ctx) + "/blocklist?pair=" + pair(ctx)).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.doOutput = true
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-admin-key", key(ctx))
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val ok = code in 200..299
                p(ctx).edit().putString("last", if (ok) "تمت المزامنة " + java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) else "فشلت المزامنة ($code)").apply()
                onResult?.invoke(ok, if (ok) "تمت المزامنة" else if (code == 401) "المفتاح السري غلط" else "فشلت ($code)")
            } catch (e: Exception) {
                p(ctx).edit().putString("last", "فشلت المزامنة (ما في نت)").apply()
                onResult?.invoke(false, "ما قدرت أتصل بالوسيط")
            }
        }.start()
    }
    fun lastStatus(ctx: Context) = p(ctx).getString("last", "ما تمت مزامنة بعد") ?: ""
}
