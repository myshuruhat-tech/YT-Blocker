package com.example.ytblocker

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    // ───────── الألوان ─────────
    private val cBg = Color.parseColor("#0A0A0C")
    private val cCard = Color.parseColor("#141418")
    private val cCardAlt = Color.parseColor("#1C1C22")
    private val cStroke = Color.parseColor("#2A2A32")
    private val cText = Color.parseColor("#F4F4F6")
    private val cMuted = Color.parseColor("#9A9AA6")
    private val cMint = Color.parseColor("#34D399")
    private val cBlue = Color.parseColor("#60A5FA")
    private val cAmber = Color.parseColor("#FBBF24")
    private val cRose = Color.parseColor("#FB7185")

    private data class Entry(val ts: String, val phone: String, val type: String, val label: String)

    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var prefs: SharedPreferences
    private var filter = "الكل"
    private var shown = 100
    private var techOpen = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "activitylog") runOnUiThread { rebuild(keepScroll = true) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("diag", Context.MODE_PRIVATE)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        scroll = ScrollView(this).apply {
            setBackgroundColor(cBg)
            isVerticalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(40))
        }
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        rebuild(keepScroll = false)
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onPause()
    }

    // ───────── أدوات مساعدة ─────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density
    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun bg(fill: Int, radius: Float, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dpf(radius)
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun pill(text: String, color: Int, filled: Boolean = false, size: Float = 12f): TextView =
        tv(text, size, if (filled) Color.BLACK else color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(5), dp(12), dp(5))
            background = bg(if (filled) color else alpha(color, 40), 100f)
        }

    private fun lp(w: Int, h: Int, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(top) }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun typeColor(t: String) = when (t) {
        "مشاهدة" -> cBlue
        "إخفاء" -> cAmber
        "حجب" -> cRose
        else -> cMuted
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val full = "$packageName/${BlockerService::class.java.name}"
        val short = "$packageName/.BlockerService"
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun readEntries(): List<Entry> {
        val raw = prefs.getString("activitylog", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.map { line ->
            val p = line.split(" | ", limit = 4)
            if (p.size == 4) {
                val type = when (p[2]) { "تغطية" -> "إخفاء"; "رجوع" -> "حجب"; else -> p[2] }
                Entry(p[0], p[1], type, p[3])
            } else Entry("", "", "", line)
        }
    }

    // ───────── بناء الشاشة ─────────
    private fun rebuild(keepScroll: Boolean) {
        val y = scroll.scrollY
        content.removeAllViews()
        val entries = readEntries()
        content.addView(header())
        content.addView(statusCard(), lp(MATCH, WRAP, 18))
        content.addView(statsRow(entries), lp(MATCH, WRAP, 12))
        content.addView(logTitle(entries.size), lp(MATCH, WRAP, 26))
        content.addView(filters(), lp(MATCH, WRAP, 12))
        addLog(entries)
        content.addView(techCard(), lp(MATCH, WRAP, 28))
        if (keepScroll) scroll.post { scroll.scrollTo(0, y) }
    }

    private fun header(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logoBox = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setShape(GradientDrawable.OVAL)
                setColor(Color.BLACK)
                setStroke(dp(1), cStroke)
            }
        }
        logoBox.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(60), dp(60)))
        row.addView(logoBox, LinearLayout.LayoutParams(dp(60), dp(60)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv("5al", 26f, cText, true))
        col.addView(tv("يخفي القنوات المحظورة من يوتيوب ويسجّل كل ما تشاهده", 13f, cMuted).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        return row
    }

    private fun statusCard(): View {
        val on = serviceEnabled()
        val accent = if (on) cMint else cRose
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(alpha(accent, 46), cCard)
            ).apply {
                cornerRadius = dpf(22f)
                setStroke(dp(1), alpha(accent, 110))
            }
        }
        card.addView(pill(if (on) "●  الحماية مفعّلة" else "●  الحماية متوقفة", accent), LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(
            tv(
                if (on) "5al يراقب يوتيوب الآن، ويخفي القنوات المحظورة ويسجّل ما تفتحه من فيديوهات."
                else "لتشغيل الحماية: افتح إعدادات إمكانية الوصول، اختر «5al» ثم شغّله.",
                14f, cText
            ).apply { setLineSpacing(dpf(3f), 1f) },
            lp(MATCH, WRAP, 12)
        )
        card.addView(
            tv(if (on) "إعدادات الخدمة" else "تشغيل الحماية", 15f, Color.BLACK, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(13), dp(16), dp(13))
                background = bg(accent, 100f)
                setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            },
            lp(MATCH, WRAP, 16)
        )
        return card
    }

    private fun todayPrefix(daysAgo: Int = 0): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }

    private fun statsRow(entries: List<Entry>): View {
        val today = todayPrefix()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val items = listOf("مشاهدة" to "مشاهدات اليوم", "إخفاء" to "بطاقات مخفية", "حجب" to "فيديوهات محجوبة")
        items.forEachIndexed { i, (type, title) ->
            val n = entries.count { it.type == type && it.ts.startsWith(today) }
            val c = typeColor(type)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(14), dp(8), dp(14))
                background = bg(alpha(c, 28), 18f, alpha(c, 70))
            }
            box.addView(tv(n.toString(), 24f, c, true).apply { gravity = Gravity.CENTER })
            box.addView(tv(title, 11f, cMuted).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) })
            row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
        return row
    }

    private fun logTitle(total: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(tv("سجل النشاط", 18f, cText, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(pill("$total", cMuted))
        if (total > 0) {
            row.addView(pill("مسح", cRose).apply {
                setOnClickListener { confirmClear() }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        }
        return row
    }

    private fun filters(): View {
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("الكل", "مشاهدة", "إخفاء", "حجب").forEachIndexed { i, name ->
            val selected = filter == name
            val c = if (name == "الكل") cText else typeColor(name)
            val chip = tv(name, 13f, if (selected) Color.BLACK else cMuted, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(8), dp(18), dp(8))
                background = if (selected) bg(c, 100f) else bg(cCardAlt, 100f, cStroke)
                setOnClickListener { filter = name; shown = 100; rebuild(keepScroll = true) }
            }
            row.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { if (i > 0) marginStart = dp(8) })
        }
        hs.addView(row)
        return hs
    }

    private fun addLog(all: List<Entry>) {
        val list = if (filter == "الكل") all else all.filter { it.type == filter }
        if (list.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(34), dp(20), dp(34))
                background = bg(cCard, 20f, cStroke)
            }
            empty.addView(tv("لا يوجد نشاط بعد", 16f, cText, true).apply { gravity = Gravity.CENTER })
            empty.addView(
                tv("افتح يوتيوب وشاهد أي فيديو، وسيظهر هنا فورًا.", 13f, cMuted).apply {
                    gravity = Gravity.CENTER
                    setPadding(0, dp(6), 0, 0)
                }
            )
            content.addView(empty, lp(MATCH, WRAP, 14))
            return
        }
        val today = todayPrefix()
        val yesterday = todayPrefix(1)
        var lastDay = ""
        list.take(shown).forEach { e ->
            val day = if (e.ts.length >= 10) e.ts.substring(0, 10) else ""
            if (day != lastDay) {
                lastDay = day
                val name = when (day) { today -> "اليوم"; yesterday -> "أمس"; "" -> "—"; else -> day }
                content.addView(tv(name, 12f, cMuted, true), lp(MATCH, WRAP, 18))
            }
            content.addView(entryCard(e), lp(MATCH, WRAP, 8))
        }
        if (list.size > shown) {
            content.addView(
                tv("عرض المزيد (${list.size - shown})", 14f, cText, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    background = bg(cCardAlt, 100f, cStroke)
                    setOnClickListener { shown += 100; rebuild(keepScroll = true) }
                },
                lp(MATCH, WRAP, 16)
            )
        }
    }

    private fun entryCard(e: Entry): View {
        val c = typeColor(e.type)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(cCard, 18f, cStroke)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (e.type.isNotEmpty()) top.addView(pill(e.type, c, size = 11f))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val time = if (e.ts.length >= 16) e.ts.substring(11, 16) else ""
        top.addView(tv(time, 12f, cMuted))
        card.addView(top)
        card.addView(
            tv(e.label.ifBlank { "—" }, 15f, cText).apply {
                maxLines = 3
                ellipsize = android.text.TextUtils.TruncateAt.END
                setLineSpacing(dpf(2f), 1f)
            },
            lp(MATCH, WRAP, 8)
        )
        if (e.phone.isNotBlank()) {
            card.addView(tv(e.phone, 11f, alpha(cMuted, 170)), lp(MATCH, WRAP, 6))
        }
        return card
    }

    private fun confirmClear() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("مسح السجل؟")
            .setMessage("سيتم حذف كل الأنشطة المسجّلة من هذا الجهاز.")
            .setPositiveButton("مسح") { _, _ ->
                prefs.edit().remove("activitylog").apply()
                rebuild(keepScroll = false)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ───────── تفاصيل للمطوّر (مطويّة افتراضيًا) ─────────
    private fun techText(): String {
        fun g(k: String, d: String = "-") = prefs.getString(k, d) ?: d
        return "الحالة:\n" + g("status", "الخدمة لم تستقبل شيئًا بعد (هل هي مفعّلة؟)") +
            "\n\nالفيديو المعروض:\n" + g("watching") +
            "\n\nالمطابقات:\n" + g("matches") +
            "\n\nأزرار:\n" + g("controls") +
            "\n\nالمشغّل المصغّر:\n" + g("mini") +
            "\n\nالعناصر:\n" + g("ids", "")
    }

    private fun techCard(): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(cCard, 18f, cStroke)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { techOpen = !techOpen; rebuild(keepScroll = true) }
        }
        head.addView(tv("تفاصيل تقنية", 14f, cMuted, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(tv(if (techOpen) "▲" else "▼", 12f, cMuted))
        card.addView(head)
        if (techOpen) {
            val body = techText()
            card.addView(
                tv(body, 11f, cMuted).apply {
                    typeface = Typeface.MONOSPACE
                    textDirection = View.TEXT_DIRECTION_LTR
                    setTextIsSelectable(true)
                },
                lp(MATCH, WRAP, 12)
            )
            card.addView(
                pill("نسخ التفاصيل", cBlue).apply {
                    setOnClickListener {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("5al", body))
                        Toast.makeText(this@MainActivity, "تم النسخ", Toast.LENGTH_SHORT).show()
                    }
                },
                lp(WRAP, WRAP, 12)
            )
        }
        return card
    }
}
