package com.example.ytblocker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "فعّل الخدمة من: إمكانية الوصول ← YT Blocker ← تشغيل"
            textSize = 18f
            gravity = Gravity.CENTER
        })
        layout.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        val out = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 12f
            textDirection = TextView.TEXT_DIRECTION_LTR
        }
        layout.addView(Button(this).apply {
            text = "تشخيص: عرض معرّفات آخر شاشة يوتيوب"
            setOnClickListener {
                val sp = getSharedPreferences("diag", Context.MODE_PRIVATE)
                out.text = "STATUS: " + sp.getString("status", "الخدمة ما استقبلت شيء (غير مفعّلة؟)") +
                    "\n\n" + sp.getString("ids", "")
            }
        })
        layout.addView(ScrollView(this).apply { addView(out) })
        setContentView(layout)
    }
}
