package com.example.ytblocker

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

class BlockerService : AccessibilityService() {

    private fun norm(s: String) = s.lowercase()
        .replace(Regex("[\\u064B-\\u065F\\u0640]"), "")
        .replace(Regex("[أإآ]"), "ا")
        .replace("ى", "ي").replace("ة", "ه")
        .replace(Regex("['’‘]"), "")
        .replace(Regex("[٠-٩]")) { (it.value[0] - '٠').toString() }
        .replace(Regex("\\s+"), " ").trim()

    // handles: فريدة، contains
    private val handles = listOf(
        "@d7oomy999", "@POWRibrahim", "@FRS9", "@FFearFFul", "@mjrmgames909",
        "@POWR_Rayan", "@iiGOATGamingg", "@POWR_ROB", "@xBear1", "@ABS11",
        "@Abo_treek1", "@Topz", "@Abunoo7", "@POWR_Rakan", "@Siiu-Team",
        "@POWR-Esports", "@SHoNgxxBoNg", "@xbear-plus", "@sxb3654",
        "@FRLplus", "@25KLOoODE", "@POWR.Kmstka", "@MSKplusss", "@Moskooo"
    ).map { norm(it) }

    // أسماء طويلة: contains
    private val names = listOf(
        "d7oomy_999", "Ibrahim | ابو خليل", "Faris | فارس", "FFearFFul",
        "MjrmGames", "POWR Rayan", "iiGOATGaming", "POWR ROB",
        "ابو عابد الشمري", "Turki | ابو تريك", "TOPZ توبز", "ابو نوح",
        "POWR Rakan", "POWR eSports", "SHoNgxBoNg", "خلودي 25",
        "كمستكا", "MOSKOO"
    ).map { norm(it) }

    // أسماء قصيرة: مطابقة تامة
    private val exact = listOf("ABS", "SXB", "F R S", "FRL+", "MSK+").map { norm(it) }.toSet()

    private val YT = "com.google.android.youtube"
    private val blockTouch = false // true = يمنع الضغط على المخفي، لكن يمنع السكرول لو بدأ عليه
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val covers = mutableListOf<View>()
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = Runnable { update() }
    private var lastBack = 0L

    private fun matches(raw: String): Boolean {
        val t = norm(raw)
        return t in exact || handles.any { t.contains(it) } || names.any { t.contains(it) }
    }

    private var evCount = 0
    private var lastPkg = ""

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString()
        evCount++
        if (pkg != packageName) lastPkg = pkg ?: ""
        if (pkg == packageName) return // أحداث الغطاء نفسه
        if (pkg != YT) { clearCovers(); return }
        handler.removeCallbacks(refresh)
        handler.postDelayed(refresh, 60)
    }

    private val watchKeys = listOf("watch_player", "watch_while", "player_view", "player_fragment", "watch_list")
    private val viewWords = listOf(" views", " view", " likes", " like", "مشاهده", "مشاهدات", "اعجاب").map { norm(it) }
    private var lastIds = ""

    private fun update() {
        val root = windows.mapNotNull { it.root }.firstOrNull { it.packageName?.toString() == YT }
            ?: rootInActiveWindow
        if (root == null || root.packageName?.toString() != YT) {
            saveDiag("no-youtube-window", "")
            clearCovers(); return
        }

        val rects = mutableListOf<Rect>()
        val menus = mutableListOf<AccessibilityNodeInfo?>()
        val keys = mutableListOf<String>()
        val ids = sortedSetOf<String>()
        var pageLevel = false
        var watchPage = false
        var watchHit = false
        val matched = mutableListOf<String>()
        val screenH = resources.displayMetrics.heightPixels

        fun collect(n: AccessibilityNodeInfo?) {
            if (n == null) return
            n.viewIdResourceName?.let { id ->
                ids.add(id)
                if (watchKeys.any { id.contains(it) }) watchPage = true
            }
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (t != null && matches(t)) {
                val nt = norm(t)
                matched.add(t.take(70).replace("\n", " "))
                // الـ @handle ما يظهر في الصفحة الرئيسية، فظهوره = فيديو/شورتس/قناة مفتوحة
                if (handles.any { nt.contains(it) }) {
                    watchHit = true
                    return
                }
                var card: AccessibilityNodeInfo? = n
                while (card != null && !card.isClickable) card = card.parent
                if (card == null) { pageLevel = true; return }
                val r = Rect()
                card.getBoundsInScreen(r)
                if (r.height() > screenH * 0.7) pageLevel = true
                else if (!r.isEmpty) {
                    rects.add(r)
                    menus.add(findMenu(card, r.height()))
                    keys.add(nt.take(40))
                }
                return
            }
            for (i in 0 until n.childCount) collect(n.getChild(i))
        }
        collect(root)

        saveDiag("ok watchHit=$watchHit watchPage=$watchPage pageLevel=$pageLevel covers=${rects.size}", ids.joinToString("\n"))
        if (matched.isNotEmpty()) {
            getSharedPreferences("diag", Context.MODE_PRIVATE).edit()
                .putString("matches", matched.joinToString("\n")).apply()
        }

        val openedBlockedVideo = watchPage && rects.any { it.top < screenH * 0.55 }

        if (pageLevel || watchHit || openedBlockedVideo) {
            val now = System.currentTimeMillis()
            if (now - lastBack > 1000) {
                lastBack = now
                // لو كان في مشغّل مصغّر قبل الرجوع (فيديو ثاني يشتغل) ما نلمسه
                val hadMini = findNode(root, closeWords) != null
                performGlobalAction(GLOBAL_ACTION_BACK)
                if (!hadMini && (watchHit || openedBlockedVideo)) stopMiniPlayer()
            }
            clearCovers()
            return
        }
        showCovers(rects)

        // ضغط تلقائي على ⋮ ← "Don't recommend channel"
        if (autoDontRecommend && !busy && System.currentTimeMillis() - lastAuto > 2000) {
            val i = keys.indices.firstOrNull { menus[it] != null && keys[it] !in skipKeys }
            if (i != null) autoDontRecommend(menus[i]!!, keys[i])
        }
    }

    private val autoDontRecommend = true // false = غطاء فقط بدون ضغط تلقائي
    private var busy = false
    private var lastAuto = 0L
    private val skipKeys = mutableSetOf<String>()

    private val menuWords = listOf(
        "action menu", "more options", "المزيد من الخيارات", "قائمه الاجراءات"
    ).map { norm(it) }
    private val dontWords = listOf(
        "dont recommend channel", "عدم اقتراح هذه القناه", "عدم اقتراح القناه"
    ).map { norm(it) }

    private fun findMenu(card: AccessibilityNodeInfo, cardH: Int): AccessibilityNodeInfo? {
        var a: AccessibilityNodeInfo? = card
        var depth = 0
        while (a != null && depth < 4) {
            val r = Rect()
            a.getBoundsInScreen(r)
            if (depth > 0 && r.height() > cardH * 1.5) break
            findNode(a, menuWords)?.let { return it }
            a = a.parent
            depth++
        }
        return null
    }

    private fun autoDontRecommend(menu: AccessibilityNodeInfo, key: String) {
        busy = true
        lastAuto = System.currentTimeMillis()
        if (!clickNode(menu)) {
            skipKeys.add(key); busy = false; return
        }
        var attempts = 0
        val r = object : Runnable {
            override fun run() {
                attempts++
                val roots = windows.mapNotNull { it.root }.filter { it.packageName?.toString() == YT }
                val node = roots.firstNotNullOfOrNull { findNode(it, dontWords) }
                if (node != null) {
                    clickNode(node)
                    skipKeys.add(key)
                    handler.postDelayed({ busy = false }, 1200)
                    return
                }
                if (attempts < 5) {
                    handler.postDelayed(this, 300)
                } else {
                    // ما لقينا الخيار: نسجّل محتوى القائمة ونسكّرها
                    logControls(roots.firstOrNull())
                    skipKeys.add(key)
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    handler.postDelayed({ busy = false }, 800)
                }
            }
        }
        handler.postDelayed(r, 400)
    }

    private val closeWords = listOf(
        "close miniplayer", "close mini player", "close mini-player",
        "اغلاق المشغل المصغر", "اغلاق المشغل الصغير"
    ).map { norm(it) }

    private fun findNode(n: AccessibilityNodeInfo?, words: List<String>): AccessibilityNodeInfo? {
        if (n == null) return null
        val t = n.contentDescription?.toString() ?: n.text?.toString()
        if (t != null) {
            val nt = norm(t)
            if (words.any { nt.contains(it) }) return n
        }
        for (i in 0 until n.childCount) findNode(n.getChild(i), words)?.let { return it }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        return c?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    // بعد الرجوع يوتيوب يصغّر الفيديو ويكمل صوته؛ ندوّر على زر إغلاق المشغّل المصغّر ونضغطه
    private fun stopMiniPlayer() {
        var attempts = 0
        val r = object : Runnable {
            override fun run() {
                attempts++
                val root = windows.mapNotNull { it.root }.firstOrNull { it.packageName?.toString() == YT }
                val node = findNode(root, closeWords)
                if (node != null && clickNode(node)) return
                if (attempts < 6) handler.postDelayed(this, 400) else logControls(root)
            }
        }
        handler.postDelayed(r, 400)
    }

    // للتشخيص: أسماء الأزرار اللي فيها mini/close/pause
    private fun logControls(root: AccessibilityNodeInfo?) {
        val found = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || found.size > 40) return
            val t = n.contentDescription?.toString() ?: n.text?.toString()
            if (t != null) {
                val l = t.lowercase()
                if (l.contains("mini") || l.contains("close") || l.contains("pause") || l.contains("recommend") || l.contains("interested") || l.contains("report") || l.contains("المصغر") || l.contains("اغلاق") || l.contains("إغلاق"))
                    found.add(t.take(50))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        getSharedPreferences("diag", Context.MODE_PRIVATE).edit()
            .putString("controls", found.joinToString("\n").ifEmpty { "-" }).apply()
    }

    private fun saveDiag(status: String, ids: String) {
        val sp = getSharedPreferences("diag", Context.MODE_PRIVATE)
        val st = "events=$evCount lastPkg=$lastPkg state=$status"
        val e = sp.edit().putString("status", st)
        if (ids.isNotEmpty() && ids != lastIds) { lastIds = ids; e.putString("ids", ids) }
        e.apply()
    }

    private fun showCovers(rects: List<Rect>) {
        while (covers.size > rects.size) {
            runCatching { wm.removeView(covers.removeAt(covers.lastIndex)) }
        }
        rects.forEachIndexed { i, r ->
            val lp = WindowManager.LayoutParams(
                r.width(), r.height(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    (if (blockTouch) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
                PixelFormat.OPAQUE
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = r.left
                y = r.top
            }
            if (i < covers.size) {
                wm.updateViewLayout(covers[i], lp)
            } else {
                // نفس لون خلفية يوتيوب عشان يبان فراغ
                val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                    Configuration.UI_MODE_NIGHT_YES
                val v = View(this).apply {
                    setBackgroundColor(if (dark) Color.rgb(15, 15, 15) else Color.WHITE)
                }
                wm.addView(v, lp)
                covers.add(v)
            }
        }
    }

    private fun clearCovers() {
        handler.removeCallbacks(refresh)
        covers.forEach { runCatching { wm.removeView(it) } }
        covers.clear()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        clearCovers()
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        clearCovers()
    }
}
